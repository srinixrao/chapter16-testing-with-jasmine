import { Component } from '@angular/core';

@Component({
  selector: 'app-change-detect-test',
  templateUrl: './change-detect-test.component.html',
  styleUrls: ['./change-detect-test.component.css']
})
export class ChangeDetectTestComponent {

   title = 'Packt Testing works';

  constructor() { }

}
